export enum GroupChangeEvent {
  Remove = 'remove',
  Add = 'add'
}
