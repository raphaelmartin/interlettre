import { InterfaceState, InterfaceMode } from '../model/enum';
export interface InterfaceChangeMode {
  displayInfo: InterfaceState;
  mode: InterfaceMode;
  info: InterfaceState;
}
