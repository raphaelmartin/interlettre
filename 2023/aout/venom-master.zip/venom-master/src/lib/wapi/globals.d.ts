declare module global {
  interface Window {
    Store: any;
  }
}
