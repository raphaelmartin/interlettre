﻿# Update checking

Whatsapp is in constant change, in order to tackle this issue I suggest keeping your Venom package always up-to-date.

The method/function names won't change, only their core algorithm. This way you won't have to makes changes in your code at every update. They will remain the same forever.
