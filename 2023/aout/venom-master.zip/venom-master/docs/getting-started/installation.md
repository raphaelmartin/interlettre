# Installation

The first thing that you had to do is install the `npm package`:

```bash
npm i --save venom-bot
```

or for [Nightly releases](https://github.com/orkestral/venom/releases/tag/nightly):

```bash
> npm i --save https://github.com/orkestral/venom/releases/download/nightly/venom-bot-nightly.tgz
```
